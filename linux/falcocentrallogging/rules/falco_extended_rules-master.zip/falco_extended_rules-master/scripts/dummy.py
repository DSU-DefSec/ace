#!/usr/bin/env python
# coding: utf-8

# In[ ]:


sum=0
for i in range(100):
    sum=sum+i
print(sum)

